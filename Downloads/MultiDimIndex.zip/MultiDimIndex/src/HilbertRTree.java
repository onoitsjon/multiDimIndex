/****************
 * Jonathan Yi 	*
 * 198:437     	*
 * 4/11/12     	*
 ****************/

import java.util.*;
import java.io.*;

class Data{
	int xcoord;		//x coordinate value
	int ycoord;		//y coordinate value
	int rid;		//record id
	
	/**
	 * Constructor for data entry
	 * @param x x coordinate value of data entry
	 * @param y y coordinate value of data entry
	 * @param hvalue Hilbert value of data entry
	 * @param rid record id of data entry
	 */
	public Data(int x, int y, int rid){
		this.xcoord = x;
		this.ycoord = y;
		this.rid = rid;
	}
}

class IndexEntry{
	Data[] page;		//data page of index entry
	int lower_left_x;	//x coordinate value of lower left corner of minimum bounding box
	int lower_left_y;	//y coordinate value of lower left corner of minimum bounding box
	int upper_right_x;	//x coordinate value of upper right corner of minimum bounding box
	int upper_right_y;	//y coordinate value of upper right corner of minimum bounding box
	boolean isRoot;		//true means the index entry is the root of the R-tree
	IndexEntry[] next;	//pointer to child entry
	
	/**
	 * Constructor for lowest level index entry that initializes the corners of the minimum bounding box based on the data page
	 * @param page array of Data which represents the data page of the IndexEntry
	 * @param isRoot boolean that determines whether the IndexEntry is part of the root
	 */
	public IndexEntry(Data[] page, boolean isRoot){
		this.page = new Data[341];
		System.arraycopy(page, 0, this.page, 0, this.page.length);
		int minx = page[0].xcoord;
		int maxx = page[0].xcoord;
		int miny = page[0].ycoord;
		int maxy = page[0].ycoord;
		for(int k = 1; k< page.length;k++){		//search thru data page for minimum and maximum for x and y
			if(page[k] == null){
				break;
			}
			else{
				if(page[k].xcoord < minx)
					minx = page[k].xcoord;
				if(page[k].xcoord > maxx)
					maxx = page[k].xcoord;
				if(page[k].ycoord < miny)
					miny = page[k].ycoord;
				if(page[k].ycoord > maxy)
					maxy = page[k].ycoord;
			}
		}
		this.lower_left_x = minx;		//set this IndexEntry's minimum bounding box corners
		this.upper_right_x = maxx;
		this.lower_left_y = miny;
		this.upper_right_y = maxy;
		this.isRoot = isRoot;
	}
	
	/**
	 * Empty constructor
	 */
	public IndexEntry(){
		
	}
	
	/**
	 * Function to initialize the parent's fields based on the children index entries 
	 * After this call, the field isRoot needs to be set
	 * @param child tree of IndexEntry[] that represent 
	 * @return 0 = successful initialization, -1 = unsuccessful because child is not full
	 */
	public int parentInitialize(IndexEntry[] child){
		int minx = child[0].lower_left_x;
		int maxx = child[0].upper_right_x;
		int miny = child[0].lower_left_y;
		int maxy = child[0].upper_right_y;
		for(int z = 1; z < child.length; z++){		//search through IndexEntry[] child
			if(child[z] == null){
				break;
			}
			else{						//find minimum and maximum for x and y
				if(child[z].lower_left_x < minx)
					minx = child[z].lower_left_x;
				if(child[z].upper_right_x > maxx)
					maxx = child[z].upper_right_x;
				if(child[z].lower_left_y < miny)
					miny = child[z].lower_left_y;
				if(child[z].upper_right_y > maxy)
					maxy = child[z].upper_right_y;
				child[z].isRoot = false;
			}
		}
		this.lower_left_x = minx;			//set this IndexEntry's minimum bounding box corners based on minimum and maximum corners of child
		this.lower_left_y = miny;
		this.upper_right_x = maxx;
		this.upper_right_y = maxy;
		this.page = null;
		this.next = child;					//point IndexEntry's next level to IndexEntry[] child 
		return 0;
	}
	
	/**
	 * Function to recalculate an IndexEntry's minimum bounding box corners after a successful insertion to its children 
	 * @return 0 if successful, -1 if unsuccessful
	 */
	public int refactor(){
		if(this.next != null){
			int minx = this.next[0].lower_left_x;
			int maxx = this.next[0].upper_right_x;
			int miny = this.next[0].lower_left_y;
			int maxy = this.next[0].upper_right_y;
			for(int i = 0; i<this.next.length; i++){
				if(this.next[i] == null){
					break;
				}
				else{
					if(this.next[i].lower_left_x < minx)
						minx = this.next[i].lower_left_x;
					if(this.next[i].upper_right_x > maxx)
						maxx = this.next[i].upper_right_x;
					if(this.next[i].lower_left_y < miny)
						miny = this.next[i].lower_left_y;
					if (this.next[i].upper_right_y > maxy)
						maxy = this.next[i].upper_right_y;
				}
			}
			this.lower_left_x = minx;
			this.upper_right_x = maxx;
			this.lower_left_y = miny;
			this.upper_right_y = maxy;
			return 0;
		}
		else{
			return -1;
		}
	}
	
	/**
	 * Function to determine whether the coordinates x and y exist in the minimum bounding box of this IndexEntry
	 * @param x	x coordinate
	 * @param y y coordinate
	 * @return true if x and y is bounded by this IndexEntry's minimum bounding box, false if x and y lie outside the box
	 */
	public boolean contains(int x, int y){
		if(x<=this.upper_right_x && x>=this.lower_left_x && y<=this.upper_right_y && y>=this.lower_left_y)
			return true;
		return false;
	}
	
	/**
	 * Function to determine the area of the minimum bounding box for this IndexEntry
	 * @return -1 if there are no children, x>=0 where x is the area of the minimum bounding box
	 */
	public int getArea(){
		int area = -1;
		if(this.next != null){
			int minx = this.next[0].lower_left_x;
			int maxx = this.next[0].upper_right_x;
			int miny = this.next[0].lower_left_y;
			int maxy = this.next[0].upper_right_y;
			for(int i = 0; i<this.next.length; i++){
				if(this.next[i] == null){
					break;
				}
				else{
					if(this.next[i].lower_left_x < minx)
						minx = this.next[i].lower_left_x;
					if(this.next[i].upper_right_x > maxx)
						maxx = this.next[i].upper_right_x;
					if(this.next[i].lower_left_y < miny)
						miny = this.next[i].lower_left_y;
					if (this.next[i].upper_right_y > maxy)
						maxy = this.next[i].upper_right_y;
				}
			}
			area = Math.abs(maxy-miny)*Math.abs(maxx-minx);
			return area;
		}
		return area;
	}
}

class Candidate{
	int index;		//index of IndexEntry array
	int area;		//area of least enlargement or smallest fit
	
	/**
	 * Constructor for Candidate
	 * @param index index of IndexEntry[]
	 * @param area area of least enlargement or smallest fit
	 */
	public Candidate(int index, int area){
		this.index = index;
		this.area = area;
	}
	
	/**
	 * Function to compare area of Candidate
	 * @param can Candidate to compare area with this Candidate
	 * @return 0 if equal, -1 if less than, 1 if greater than
	 */
	public int compareTo(Candidate can){
		if(this.area == can.area) return 0;
		else if(this.area < can.area) return -1;
		else return 1;
	}
}

/**
 * Comparator object with compare function to compare Candidate area
 */
class CComparator implements Comparator<Object>{
	public int compare (Object can1, Object can2){
		if(can1 != null && can2 != null)
			return ((Candidate)can1).compareTo(((Candidate)can2));
		return 0;
	}
}

/**
 * Comparator object with compare function to compare Wrapper Hilbert value
 */
class HComparator implements Comparator<Object>{
	public int compare(Object ent1, Object ent2){
		if(ent1 != null && ent2 != null)
			return ((Wrapper)ent1).compareTo(((Wrapper)ent2));
		return 0;
	}
}

/**
 */
class Wrapper{
	Data data;
	long hvalue;
	
	/**
	 * Function to compare Hilbert value of data
	 * @param data Data to compare with this Data's hval
	 * @return 0 if equal, -1 if less than, 1 if greater than
	 */
	public int compareTo(Wrapper wrap){
		if(this.hvalue == wrap.hvalue) return 0;
		else if(this.hvalue < wrap.hvalue) return -1;
		else return 1;
	}
}

public class HilbertRTree {
	/**
	 * Function to obtain Hilbert value from x,y coordinate
	 * @param x value of x-coordinate
	 * @param y value of y-coordinate
	 * @return Hilbert value of x,y coordinate
	 */
    static long getHilbertValue(int x, int y) {
        long res = 0;
        int num_bits_x = 1;
        int num_bits_y = 1;
        
        if(x != 0)
        	num_bits_x = (int)(Math.log(x)/Math.log(2))+1;
        if(y != 0)
        	num_bits_y = (int)(Math.log(y)/Math.log(2))+1;
        
        int BITS_PER_DIM = Math.max(num_bits_x, num_bits_y);
        
        for (int ix = BITS_PER_DIM - 1; ix >= 0; ix--) {
            long h = 0;
            long b1 = (x & (1 << ix)) >> ix;
            long b2 = (y & (1 << ix)) >> ix;

            if (b1 == 0 && b2 == 0) {
                h = 0;
            } else if (b1 == 0 && b2 == 1) {
                h = 1;
            } else if (b1 == 1 && b2 == 0) {
                h = 3;
            } else if (b1 == 1 && b2 == 1) {
                h = 2;
            }
            res += h << (2 * ix);
        }
        return res;
    }
    
    /**
     * Recursive function to insert data page into R-tree
     * @param target currently focused index entry level
     * @param page data page to be inserted
     * @return 0 = insert successful, -1 = error page is null, x>0 = make newroot where newroot[0] is old root and newroot[1] is a parent with x children
     */
    static int insert(IndexEntry target[], Data[] page){
    	if(page == null) return -1;
    	if(target == null) return -1;
    	if(target[0] == null){					//root is empty
    		target[0] = new IndexEntry(page, true);
    		return 0;							//Data page successfully inserted
    	}
    	else if(target[0].next == null){		//IndexEntry target is the lowest level IndexEntry in the R-Tree
    		int g;
    		for(g = 0; g<target.length;g++){	//search through target for empty index
    			if(target[g] == null){			//empty index found
    				boolean root;
    				if(target[0].isRoot)
    					root = true;
    				else
    					root = false;
    				target[g] = new IndexEntry(page, root);
    				return 0;		//Data page successfully inserted
    			}
    		}
    		//if this is reached, IndexEntry target is the lowest level and is full
    		return 1;				//return to parent
    	}
    	else if(target[0].next != null){		//target is not the lowest index level
    		ArrayList<Candidate> smallestIndex = new ArrayList<Candidate>();
    		ArrayList<Candidate> leastIndex = new ArrayList<Candidate>();
    		for(int g= 0; g<target.length; g++){	//search through this index level
    			if(target[g] != null){				//find candidate IndexEntry for minimum bounding box with smallest fit or least enlargement
    				int fit = HilbertRTree.doesItFit(page, target[g]);
    				if(fit > -1){
    					Candidate can = new Candidate(g, fit);
    					smallestIndex.add(can);
    				}
    				else{
    					int enlarge = HilbertRTree.howLarge(page, target[g]);
    					Candidate can = new Candidate(g, enlarge);
    					leastIndex.add(can);
    				}
    			}
    			else{
    				break;
    			}
    		}
    		Collections.sort(smallestIndex, new CComparator());		//sort candidates by increasing area
    		Collections.sort(leastIndex, new CComparator());
    		int scount = 0;
    		int lcount = 0;
    		int check;
    		
    		if(smallestIndex.isEmpty() == false){	//smallest fitting boxes exist
    			check = HilbertRTree.insert(target[smallestIndex.get(scount).index].next, page);
    			if(check==0){			//insert successful
    				target[smallestIndex.get(scount).index].refactor();
    				return 0;
    			}
    			//leaf was full for target[smallestIndex.get(scount).index]
    			scount++;		//search other smallest fitting candidates
    			while(scount < smallestIndex.size() && smallestIndex.get(scount) != null){
    				check = HilbertRTree.insert(target[smallestIndex.get(scount).index].next, page);
    				if(check==0){		//insert successful
    					target[smallestIndex.get(scount).index].refactor();
    					return 0;
    				}
    				scount++;
    			}
    		}
    		if(leastIndex.size() == 0){
    			return 1;
    		}
    		//if this is reached, all the smallest fitting candidates had full children
    		check = HilbertRTree.insert(target[leastIndex.get(lcount).index].next, page);
    		if(check==0){				//insert successful
    			target[leastIndex.get(lcount).index].refactor();
    			return 0;
    		}
    		//leaf was full for target[leastIndex.get(lcount).index]
    		lcount++;		//search other least enlargement candidates
    		while(lcount < leastIndex.size() && leastIndex.get(lcount) != null){
    			check = HilbertRTree.insert(target[leastIndex.get(lcount).index].next, page);
    			if(check==0){			//insert successful
    				target[leastIndex.get(lcount).index].refactor();
    				return 0;
    			}
    		 	lcount++;
    		}
    		//if this is reached, all the least enlargement candidates had full children
    		for(int r = 0; r < target.length; r++){		//search this level for empty index
    			if(target[r] == null){
    				IndexEntry[] lowestIndex = new IndexEntry[203];
    				lowestIndex[0] = new IndexEntry(page, false);	//create lowest index level based on page
    				IndexEntry[] childPtr = lowestIndex;
    				for(int c = 1; c<check;c++){		//create c levels of nested IndexEntries where c = check
    					IndexEntry[] parent = new IndexEntry[203];
    					parent[0] = new IndexEntry();
    					parent[0].parentInitialize(childPtr);
    					childPtr = parent;				//childPtr points to the top of this level
    				}
    				target[r] = new IndexEntry();
    				if(target[0].isRoot){
    					target[r].isRoot = true;
    				}
    				else{
    					target[r].isRoot = false;
    				}
    				target[r].parentInitialize(childPtr);	//make empty index the parent of childPtr
    				return 0;
    			}
    		}
    		return (check+1);	//this level is full, return to parent
    	}
    	return -1;		//something went wrong
    }
    /**
     * Function to determine whether a given data entry will fit inside the minimum bounding box of an index entry
     * @param data data entry
     * @param index index entry
     * @return -1 = cannot fit inside, X>0 = X is the area of index that the data can fit into 
     */
    static int doesItFit(Data[] data, IndexEntry index){
    	IndexEntry test = new IndexEntry(data, false);
    	if(	test.getArea() <= index.getArea() &&
    		test.lower_left_x >= index.lower_left_x && 
    		test.lower_left_y >= index.lower_left_y &&
    		test.upper_right_x <= index.upper_right_x &&
    		test.upper_right_y <= index.upper_right_y){
    		return index.getArea();
    	}
    	else{
    		return -1;	
    	}
    }
    
    /**
     * Function to determine area of enlargement for the minimum bounding box of IndexEntry
     * @param data Data[] used to find minimum bounding box of data points
     * @param index target IndexEntry to enlarge to
     * @return x>0 area of least enlargement
     */
    static int howLarge(Data[] data, IndexEntry index){
    	IndexEntry test = new IndexEntry(data, false);
    	int minx = Math.min(test.lower_left_x, index.lower_left_x);
    	int maxx = Math.max(test.upper_right_x, index.upper_right_x);
    	int miny = Math.min(test.lower_left_y, index.lower_left_y);
    	int maxy = Math.max(test.upper_right_y, index.upper_right_y);
    	return ((Math.abs(maxx - minx) * Math.abs(maxy-miny))-test.getArea());
    }
    
    /**
     * Search function to find whether the R-tree contains the data with coordinates x,y and returns the number of disk accesses
     * @param x x coordinate
     * @param y y coordinate
     * @param target level of IndexEntry
     * @param total counter of total disk accesses (or searches thru an IndexEntry)
     * @return x>0 if point doesn't exist, x<0 if point does exist where x = total number of checked IndexEntries
     */
    static int pointQuery(int x, int y, IndexEntry[] target, int total){
    	if(target[0].next == null){					//target is lowest index level
    		total++;
    		for(int p=0; p<target.length; p++){		//search thru index level
    			if(target[p]!= null){
	    			if(target[p].contains(x, y)){		//if minimum bounding box of index contains x and y
	    				total++;
	    				for(int w=0; w<target[p].page.length; w++){		//search thru data page
	    					if(target[p].page[w].xcoord == x && target[p].page[w].ycoord == y){
	    						System.out.printf("Coordinate (%d,%d) located in R-Tree, rid value = %d, ", x, y, target[p].page[w].rid);
	    						return (total*-1);			//return negative total because coordinate was successfully found
	    					}
	    				}
	    			}
    			}
    			else{
    				break;
    			}
    		}
    		return total;		//point does not exist in this index level
    	}
    	else{				//target is not the lowest index level
    		total++;
    		for(int p=0; p<target.length; p++){		//search thru index level
    			if(target[p]!= null){
    				if(target[p].contains(x, y)){	//if minimum bounding box of index contains x and y
        				total = HilbertRTree.pointQuery(x, y, target[p].next, total);		//check if x and y exists in minimum bounding box of target[p].next
        				if(total < 0)
        					return total;		//data point found, return to parent
        			}
    			}
    			else{
    				break;
    			}
    		}
    		return total;	//return total number of index entires searched
    	}
	}
    
    /**
     * Search function to print data entries that lie inside a range query
     * @param x1 lowest left x coordinate of range query
     * @param y1 lowest left y coordinate of range query
     * @param x2 upper right x coordinate of range query
     * @param y2 upper right y coordinate of range query 
     * @param target level of IndexEntry
     * @return
     */
    static int rangeQuery(int x1, int y1, int x2, int y2, IndexEntry[] target, int total){
    	if(target[0].next == null){			//target is lowest index level
    		total++;
    		for(int k = 0; k<target.length; k++){	//search through target index level
    			if(target[k] != null){
	    			if(	target[k].contains(x1, y1) || target[k].contains(x1, y2) || target[k].contains(x2, y1) || target[k].contains(x2,y2) ||
	    				(target[k].lower_left_x>=x1 && target[k].upper_right_x<=x2 && target[k].lower_left_y>=y1 && target[k].lower_left_y<=y2) ||
	    				(target[k].lower_left_x>=x1 && target[k].lower_left_x<=x2 && target[k].lower_left_y>=y1 && target[k].upper_right_y<=y2) ||
	    				(target[k].lower_left_x>=x1 && target[k].upper_right_x<=x2 && target[k].upper_right_y>=y1 && target[k].upper_right_y<=y2) ||
	    				(target[k].upper_right_x>=x1 && target[k].upper_right_x<=x2 && target[k].lower_left_y>=y1 && target[k].upper_right_y<=y2)	){
	    				//range query overlaps minimum bounding box of target[k]
	    				//
	    				total++;
	    				for(int s = 0; s < target[k].page.length; s++){			//search through data page
	    					if(target[k].page[s] != null){
		    					if(	target[k].page[s].xcoord >= x1 && target[k].page[s].xcoord <= x2 &&
		    						target[k].page[s].ycoord >= y1 && target[k].page[s].ycoord <= y2	){		//data entry fits in range query
		    						System.out.printf("(%d,%d),\trid = %d,\t%d disk accesses to search\n", target[k].page[s].xcoord, target[k].page[s].ycoord, target[k].page[s].rid, total);
		    					}
	    					}
	    					else{
	    						break;
	    					}
	    				}
	    			}
    			}
    			else{
    				break;
    			}
    		}
    		return total;
    	}
    	else{		//target is not the lowest index level
    		total++;
    		for(int k = 0; k<target.length; k++){	//search through target index level
    			if(target[k] != null){
    				if(	target[k].contains(x1, y1) || target[k].contains(x1, y2) || target[k].contains(x2, y1) || target[k].contains(x2,y2) ||
    	    			(target[k].lower_left_x>=x1 && target[k].upper_right_x<=x2 && target[k].lower_left_y>=y1 && target[k].lower_left_y<=y2) ||
    	    			(target[k].lower_left_x>=x1 && target[k].lower_left_x<=x2 && target[k].lower_left_y>=y1 && target[k].upper_right_y<=y2) ||
    	    			(target[k].lower_left_x>=x1 && target[k].upper_right_x<=x2 && target[k].upper_right_y>=y1 && target[k].upper_right_y<=y2) ||
    	    			(target[k].upper_right_x>=x1 && target[k].upper_right_x<=x2 && target[k].lower_left_y>=y1 && target[k].upper_right_y<=y2)	){
    	    			//range query overlaps minimum bounding box of target[k]
    						//
    	    				total = HilbertRTree.rangeQuery(x1,y1, x2, y2, target[k].next, total);		//search target[k] children
    	    			}
    			}
    			else{
    				break;    				
    			}
    		}
    		return total;
    	}
    }
    
    static int getLevels(IndexEntry[] target){
    	int num = -1;
    	if(target != null){
    		IndexEntry[] ptr;
    		num = 1;
    		if(target[0]!= null){
	    		ptr = target[0].next;
	    		while(ptr != null){
	    			num++;
	    			ptr = ptr[0].next;
	    		}
    		}
    	}
    	return num;
    }

    /**
     * Function that finds the xy-coordinate that maximizes the function a*x+b*y where a and b are positive real user inputs and a+b=1
     * @param a positive real user input
     * @param b positive real user input
     * @param bulk Wrapper[] sorted by hvalue
     * @return 0
     */
	static int maxFun(double a, double b, Wrapper[] bulk){
		int i = (bulk.length-1);
		double max = -1;
		int maxIndex = -1;
		while(i>=0){
			if((a*bulk[i].data.xcoord + b*bulk[i].data.ycoord) > max){
				max = a*bulk[i].data.xcoord + b*bulk[i].data.ycoord;
				maxIndex = i;
			}
			i--;
		}
		System.out.printf("(%d,%d)\trid=%d\t%g*%d + %g*%d = %g\n\n", bulk[maxIndex].data.xcoord, bulk[maxIndex].data.ycoord, bulk[maxIndex].data.rid, a, bulk[maxIndex].data.xcoord, b, bulk[maxIndex].data.ycoord, max);
		return 0;
	}
    
	public static void main(String[] args)throws FileNotFoundException{
		Wrapper[] bulk = new Wrapper[30000];
		int i = 0;
		int rid = 0;
		String inputfile = new String("project3dataset30K.txt");
		
		/*Open and read file line by line for data points and load into bulk array*/
		System.out.printf("Opening and reading from file \'%s\'... ", inputfile);
		Scanner sc = null;
		try {
			sc = new Scanner(new FileReader(inputfile));
		} catch (FileNotFoundException e1) {
			System.out.printf("\n\'%s\' not found\n", inputfile);
			System.exit(0);
		}
		while(sc.hasNext()){
			String tokens[] = sc.next().split(",");
			int x = Integer.parseInt(tokens[0]);
			int y = Integer.parseInt(tokens[1]);
			long hvalue = HilbertRTree.getHilbertValue(x, y);
			Data data = new Data(x, y, rid);
			bulk[i] = new Wrapper(); 
			bulk[i].data = data;
			bulk[i].hvalue = hvalue;
			i++;
			rid++;
		}
		sc.close();
		System.out.println("complete");
		
		/*Sort the array of data points for bulk loading (gives n*log(n) performance)*/
		System.out.printf("Sorting data... ");
		Arrays.sort(bulk, new HComparator());
		System.out.println("complete");
		
		/*Create and initialize R-tree*/
		System.out.printf("Creating and initializing R-Tree... \n");
		IndexEntry[] root;
		root = new IndexEntry[203];
		Data[] data_page;
		i = 0;
		int e;
		while(i<bulk.length){					//iterate thru bulk array
			e = 0;
			data_page = new Data[341];
			while(e < data_page.length && i < bulk.length){				//load data from bulk array into data page 
				if(bulk[i]!= null){
					data_page[e] = bulk[i].data;
					e++;
					i++;
				}
				else{
					i=30001;
					break;
				}
			}
			int check = HilbertRTree.insert(root, data_page);		//insert data page into R-Tree
			if(check == 0){											//insert successful
				for(int r=0; r<root.length;r++){					//refactor root level
					if(root[r]!= null)
						root[r].refactor();
					else{
						break;
					}
				}
			}
			else if (check > 0){						//replace root
				for(int r = 0; r<root.length; r++){		//change isRoot field of old root entries
					if(root[r] == null){
						break;
					}
					else{
						root[r].isRoot = false;
					}
				}
				IndexEntry[] newroot = new IndexEntry[203];	//new root made
				newroot[0] = new IndexEntry();
				newroot[0].parentInitialize(root);			//new root point to old root
				newroot[0].isRoot = true;
				
    			IndexEntry[] lowestIndex = new IndexEntry[203];
    			lowestIndex[0] = new IndexEntry(data_page, false);	//lowest IndexEntry level made
    			IndexEntry[] childPtr = lowestIndex;
    			for(int c = 1; c<check;c++){		//create c levels of nested IndexEntries where c = check
    				IndexEntry[] parent = new IndexEntry[203];
    				parent[0] = new IndexEntry();
    				parent[0].parentInitialize(childPtr);
    				childPtr = parent;					//childPtr points to top index level
    			}
    			newroot[1] = new IndexEntry();
    			newroot[1].isRoot = true;
    			newroot[1].parentInitialize(childPtr);	//index 1 of new root inserts lowest IndexEntry 
    			root = newroot;							//insert and new root creation successful
			}
			else{
				System.out.printf("\tcheck = %d something went wrong\n", check);
			}
		}
		if(i == 30000 || i == 30001)
			System.out.printf("Database successfully built, ");
		System.out.printf("%d index level(s) created\n", HilbertRTree.getLevels(root));
		
		System.out.println("Beginning query section...\n\nSearch for a point (\'x,y\' without quotes)\nor range of points (\'a,b-c,d\' without quotes: a,b and c,d are the lower left and upper right x,y coordinates, respectively)\nor type \'max function\' to find the point maximizing function a*x+b*y\nType \'exit\' when finished");
		Scanner scan = new Scanner(System.in);
		String query = scan.nextLine();		//get user input for query
		while (query.equals("exit") == false){
			if(query.equals("max function")){
				System.out.println("Input two real numbers separated by coma for A and B");
				query = scan.nextLine();
				StringTokenizer stok = new StringTokenizer(query,",");
				int num = stok.countTokens();
				double a=-1, b=-1;
				if(num == 2){
					try{
						a = Double.parseDouble(stok.nextToken());
						b = Double.parseDouble(stok.nextToken());
					}catch (NumberFormatException err){
						System.out.println("Incorrect format, A and B must be positive real numbers where A+B=1\n");
					}
					if(a <= 0 || b <=0 || (a+b)!=1)
						System.out.println("Incorrect format, A and B must be positive real numbers where A+B=1\n");
					else{
						maxFun(a,b, bulk);
					}
				}
				else{
					System.out.println("Incorrect format, A and B must be positive real numbers where A+B=1\n");
				}
				System.out.println("Search for a point, a range of points, or the point maximizing function a*x+b*y\nType 'exit' when finshed");
				query = scan.nextLine();
			}
			else{
				StringTokenizer stok = new StringTokenizer(query, ",-");
				int num = stok.countTokens();
				if(num == 4){			//range query
					int x1=-1,y1=-1,x2=-1,y2=-1;
					try{
						x1 = Integer.parseInt(stok.nextToken());
						y1 = Integer.parseInt(stok.nextToken());
						x2 = Integer.parseInt(stok.nextToken());
						y2 = Integer.parseInt(stok.nextToken());
					}catch (NumberFormatException err){
						System.out.println("Incorrect format\nRange format(\'a,b-c,d\' without quotes: a,b and c,d are the lower left and upper right x,y coordinates, respectively, and must be integers contained in [0-10000])\n");
					}
					if(x1 != -1 && x2 != -1 && y1 != -1 && y2 != -1){
						if(x1>10000 || y1>10000 || x2>10000 || y2>10000 || x1>x2 || y1>y2){
							System.out.println("Incorrect format\nRange format(\'a,b-c,d\' without quotes: a,b and c,d are the lower left and upper right x,y coordinates, respectively, and must be integers contained in [0-10000])\n");
						}
						else{
							int total = 0;
							System.out.printf("Data points found in minimum bounding box with corners (%d,%d) and (%d,%d)\n", x1,y1,x2,y2);
							HilbertRTree.rangeQuery(x1,y1,x2,y2,root, total);
							System.out.println("Query complete\n");
						}					
					}
				}
				else if (num == 2){		//point query
					int x=-1, y= -1;
					try{
						x = Integer.parseInt(stok.nextToken());
						y = Integer.parseInt(stok.nextToken());
					}catch (NumberFormatException err){
						System.out.println("Incorrect format\npoint format (\'x,y\' without quotes: x,y are the x and y coordinates of the point and must be integers contained in [0-10000])\n");
					}
					if(x != -1 && y != -1){
						if(x>10000 || y > 10000){
							System.out.println("Incorrect format\npoint format (\'x,y\' without quotes: x,y are the x and y coordinates of the point and must be integers contained in [0-10000])\n");
						}
						else{
							int total = 0;
							int check = HilbertRTree.pointQuery(x, y, root, total);
							if(check > 0)
								System.out.printf("Coordinate (%d,%d) does not exist in R-Tree, %d disk accesses to search\n", x,y, check);
							if(check < 0)
								System.out.printf("%d disk accesses to search\n", (-1*check));
							System.out.println("Query complete\n");
						}
					}
				}
				else{
					System.out.println("Incorrect format\npoint format (\'x,y\' without quotes: x,y are the x and y coordinates of the point)\nrange format(\'a,b-c,d\' without quotes: a,b and c,d are the lower left and upper right x,y coordinates, respectively)\n");
				}
				System.out.println("Search for a point, a range of points, or the point maximizing function a*x+b*y\nType 'exit' when finshed");
				query = scan.nextLine();
			}
		}
		System.out.println("Exiting program");
		System.exit(0);
	}
}
